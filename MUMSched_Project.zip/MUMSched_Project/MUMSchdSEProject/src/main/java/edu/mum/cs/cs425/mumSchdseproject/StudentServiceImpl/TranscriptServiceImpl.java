package edu.mum.cs.cs425.mumSchdseproject.StudentServiceImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.mumSchdseproject.model.Transcript;
import edu.mum.cs.cs425.mumSchdseproject.repository.TranscriptRepository;
import edu.mum.cs.cs425.mumSchdseproject.service.TranscriptService;
@Service
@Transactional
public class TranscriptServiceImpl implements TranscriptService{
	@Autowired
	TranscriptRepository transcriptRepository;
	
		public Transcript save(Transcript transcript) {
			return transcriptRepository.save(transcript);
		}

		public List<Transcript> getAllCourser() {
			return (List<Transcript>) transcriptRepository.findAll();
		}

		public Transcript getByStudentId(long stId) {
			return transcriptRepository.findByStudentId(stId);
		}

}
