package edu.mum.cs.cs425.mumSchdseproject.StudentServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.mumSchdseproject.model.Block;
import edu.mum.cs.cs425.mumSchdseproject.model.Course;
import edu.mum.cs.cs425.mumSchdseproject.model.Section;
import edu.mum.cs.cs425.mumSchdseproject.model.Student;
import edu.mum.cs.cs425.mumSchdseproject.repository.SectionRepository;
import edu.mum.cs.cs425.mumSchdseproject.service.BlockService;
import edu.mum.cs.cs425.mumSchdseproject.service.SectionService;

@Service
public class SectionServiceImpl implements SectionService{
	@Autowired
	private SectionRepository sectionRepository;
	
	@Autowired
	private BlockService blockService;

	public void saveSection(Section section) {	
		sectionRepository.save(section);
	}

	public List<Section> getAllSection() {
		return  sectionRepository.findAll();
	}

	public Section getSectionById(Long id) {
		return sectionRepository.getOne(id);
	}

	
	public void deleteSection(Long id) {
		sectionRepository.deleteById(id);
	}

	
	public void updateSection(Section section) {
		sectionRepository.save(section);
		
	}
	
	public Section createSection(Long block_id) {
		Section section = new Section();
		Block block = blockService.getBlockById(block_id);
		section.setBlock(block);
		return section;
	}
	public Section createSection(Long block_id, Course course) {
		Section section = new Section();
		Block block = blockService.getBlockById(block_id);
		section.setCourse(course);
		section.setBlock(block);
		return section;
	}
	
	public List<Student> getStudentBySection(Long id){
		return (List<Student>) sectionRepository.getOne(id);
	}
	
	public List<Section> getSectionsForFaculty(long facultyId){
		return sectionRepository.findAll();
	}


}
