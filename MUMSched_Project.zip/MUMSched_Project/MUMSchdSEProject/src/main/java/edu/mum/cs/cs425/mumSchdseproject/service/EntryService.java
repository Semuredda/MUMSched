package edu.mum.cs.cs425.mumSchdseproject.service;

import java.util.List;


import edu.mum.cs.cs425.mumSchdseproject.model.Entry;
import edu.mum.cs.cs425.mumSchdseproject.model.Section;

public interface EntryService {
	void saveEntry(Entry entry);
	Entry getEntry(Long id);
	List<Entry> getAllEntry();
	void deleteEntry(Long id);
	void updateEntry(String entryMonth, int numOfFpp, int numOfMpp, int numOfUSstudents, Long id);
	List<Section> getAllSectionsByEntryId(long id);
	Entry getEntryByMonth(String entryMonth);
	Entry findByEntryMonth(String entryMonth);
}
