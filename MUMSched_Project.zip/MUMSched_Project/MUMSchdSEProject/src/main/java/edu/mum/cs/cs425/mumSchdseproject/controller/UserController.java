package edu.mum.cs.cs425.mumSchdseproject.controller;

import edu.mum.cs.cs425.mumSchdseproject.model.Faculty;
import edu.mum.cs.cs425.mumSchdseproject.model.Student;
import edu.mum.cs.cs425.mumSchdseproject.model.User;
import edu.mum.cs.cs425.mumSchdseproject.model.dto.UserDto;
import edu.mum.cs.cs425.mumSchdseproject.repository.EntryRepository;
import edu.mum.cs.cs425.mumSchdseproject.repository.FacultyRepository;
import edu.mum.cs.cs425.mumSchdseproject.repository.StudentRepository;
import edu.mum.cs.cs425.mumSchdseproject.service.StudentService;
import edu.mum.cs.cs425.mumSchdseproject.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;


@Controller
@RequestMapping(value = "/admin/users")
public class UserController {
	
	@Autowired	
	private UserService service;
	@Autowired
	EntryRepository entryRepository;
	@Autowired
	StudentRepository studentRepository;
	@Autowired
	FacultyRepository facultyRepository;

	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView users(){
		List<User> users = service.findAllUsers();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("users", users);
		modelAndView.setViewName("user/list");
		return modelAndView;
	}
	
	@RequestMapping(value="/new", method = RequestMethod.GET)
	public String create(Model model){			
		model.addAttribute("user", new UserDto());
		model.addAttribute("entries", entryRepository.findAll());
		return "user/ceateoredit";
	}
	
	@RequestMapping(value = "/newuser", method = RequestMethod.GET)
	public String edit(@Valid @ModelAttribute("user") UserDto user,
			BindingResult result, Model model)  {

		if (result.hasErrors()) {
			model.addAttribute("errors", result.getAllErrors());
			return "user/ceateoredit";
		}

		user = service.createUser(user);
		return "redirect:/admin/users";
	}	

	@RequestMapping(value="/{id}", method = RequestMethod.GET)
	public String view(@PathVariable int id, Model model){
		model.addAttribute("entries", entryRepository.findAll());
		model.addAttribute("user", toUserDto(service.findUserById(id)));
		return "user/ceateoredit";
	}
	
	@RequestMapping(value="/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable Long id, Model model){		
		service.delete(id);
		return "redirect:/admin/users";
	}

	private UserDto toUserDto(User user){
		Student student = new Student();
		Faculty faculty = new Faculty();
		if(user.getUserType().equalsIgnoreCase("Student")){
			student = studentRepository.findByUserprofile(user);
		}else if(user.getUserType().equalsIgnoreCase("Faculty")){
			faculty = facultyRepository.findByUserProfile(user);
		}
		UserDto userDto = new UserDto(user.getId(),user.getUsername(),user.getPassword(),
				user.getLastName(),user.getFirstName(),user.getEmail(),user.getUserType(),
				student.getDegree(),student.getField(),faculty.isAvailability(),student.getEntry());

		return userDto;
	}
}
