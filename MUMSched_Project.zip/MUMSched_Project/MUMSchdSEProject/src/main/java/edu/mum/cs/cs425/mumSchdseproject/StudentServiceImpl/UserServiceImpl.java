package edu.mum.cs.cs425.mumSchdseproject.StudentServiceImpl;

import java.util.List;

import javax.transaction.Transactional;

import edu.mum.cs.cs425.mumSchdseproject.model.*;
import edu.mum.cs.cs425.mumSchdseproject.model.dto.UserDto;
import edu.mum.cs.cs425.mumSchdseproject.repository.AdminRepository;
import edu.mum.cs.cs425.mumSchdseproject.repository.FacultyRepository;
import edu.mum.cs.cs425.mumSchdseproject.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.mumSchdseproject.repository.UserRepository;
import edu.mum.cs.cs425.mumSchdseproject.service.UserService;
@Service
@Transactional
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository userRepository;

	@Autowired
	FacultyRepository facultyRepository;

	@Autowired
	StudentRepository studentRepository;

	@Autowired
	AdminRepository adminRepository;

	 
	public User saveUser(User user)
	{
		return userRepository.save(user);
	}

//	public User getUserById(Long id)
//	{
//		return userRepository.getOne(id);
//	}

//	public List<User> getAllUser()
//	{
//		return (List<User>) userRepository.findAll();
//	}


	@Override
	public List<User> findAllUsers() {
		List<User> users = userRepository.findAll();
		return users;
	}

	@Override
	public List<User> findAllFacultyUsers() {
		return userRepository.findAllByUserType("Faculty");
	}

	@Override
	public List<User> findAllAdminUsers() {
		return userRepository.findAllByUserType("Admin");
	}

	@Override
	public List<User> findAllStudentUsers() {
		return userRepository.findAllByUserType("Student");
	}

	@Override
	public UserDto updateUser(UserDto userDto) {
		return null;
	}

	@Override
	public Admin createAdminUser(UserDto adminUser) {
		User user = new User(adminUser.getUsername(),adminUser.getPassword(),adminUser.getLastName(),adminUser.getFirstName(),
				adminUser.getEmail(),adminUser.getUserType(),1);
		Authority authority = new Authority(adminUser.getUsername(),"ROLE_ADMIN");
		user.addAuthority(authority);
		Admin admin = new Admin(user);
		adminRepository.save(admin);
		return admin;
	}

	@Override
	public Faculty createFacultyDto(UserDto userDto) {
		User user = new User(userDto.getUsername(),userDto.getPassword(),userDto.getLastName(),userDto.getFirstName(),
				userDto.getEmail(),userDto.getUserType(),1);

		Authority authority = new Authority(userDto.getUsername(),"ROLE_FACULTY");
		user.addAuthority(authority);

		Faculty faculty = new Faculty(user,true);
		facultyRepository.save(faculty);
		return faculty;
	}

	@Override
	public Student createStudentUser(UserDto userDto) {
		User user = new User(userDto.getUsername(),userDto.getPassword(),userDto.getLastName(),userDto.getFirstName(),
				userDto.getEmail(),userDto.getUserType(),1);

		Authority authority = new Authority(userDto.getUsername(),"ROLE_STUDENT");
		user.addAuthority(authority);


		Student student = new Student(user,userDto.getEntry(),userDto.getDegree(),userDto.getField());
		studentRepository.save(student);
		return student;
	}

	@Override
	public User findUserById(long id) {
		return userRepository.findById(id).orElse(null);
	}

	@Override
	public UserDto createUser(UserDto user) {
		UserDto returnDto = new UserDto();
		if(user.getUserType().equalsIgnoreCase("Admin")){
			Admin adminUser = createAdminUser(user);
			returnDto.setId(adminUser.getId());
		}else if(user.getUserType().equalsIgnoreCase("Faculty")){
			Faculty facultyDto = createFacultyDto(user);
			returnDto.setId(facultyDto.getId());
		}else if(user.getUserType().equalsIgnoreCase("Student")){
			Student studentUser = createStudentUser(user);
			returnDto.setId(studentUser.getId());
		}
		return returnDto;
	}

	@Override
	public void delete(Long id) {
		userRepository.deleteById(id);
	}
}
