package edu.mum.cs.cs425.mumSchdseproject.service;


import edu.mum.cs.cs425.mumSchdseproject.model.Schedule;

import java.util.List;


public interface ScheduleService {
	Schedule generateSched(String entryMonth);
	Schedule getScheduleByEntryId(Long id);
    List<Schedule> findAll();
    Schedule findById(Long id);
    Schedule save(Schedule schedule);
    void deleteScheduleById(Long id);
}
