package edu.mum.cs.cs425.mumSchdseproject.StudentServiceImpl;

import java.sql.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.mumSchdseproject.model.Entry;
import edu.mum.cs.cs425.mumSchdseproject.model.Schedule;
import edu.mum.cs.cs425.mumSchdseproject.repository.ScheduleRepository;
import edu.mum.cs.cs425.mumSchdseproject.service.EntryService;
import edu.mum.cs.cs425.mumSchdseproject.service.ScheduleService;


@Service
@Transactional
public class ScheduleServiceImpl implements ScheduleService{
	
	@Autowired
	private EntryService entryService;
   
	
	@Autowired
	private ScheduleRepository scheduleRepository;
	
	
	private Schedule schedule = new Schedule();
	

	public Schedule generateSched(String entryMonth) {
		
		System.out.println("========>Generate schedule service called "+entryMonth);
		Entry entry = (Entry) entryService.getEntryByMonth(entryMonth);
		//System.out.println("==== generate Sched entry "+entry.getNumOfFpp());

		schedule.setGeneratedDate(new Date(new java.util.Date().getTime()));
		schedule.setStatus("Draft");
		//System.out.println("==== generate Sched entry 4 "+schedule.getEntry().getBlocks().get(1).getSections().get(0).getLimitCapacity());
        scheduleRepository.save(schedule);
		System.out.println("==== generate Sched entry 5 ");

		return schedule;
	}
	
	public Schedule getScheduleByEntryId(Long id) {
		return scheduleRepository.getOne(id);
	}

    @Override
    public List<Schedule> findAll() {
        return scheduleRepository.findAll();
    }

    @Override
    public Schedule findById(Long id) {
        return scheduleRepository.findById(id).orElse(null);
    }

    @Override
    public Schedule save(Schedule schedule) {
        return scheduleRepository.save(schedule);
    }

    @Override
    public void deleteScheduleById(Long id) {
        scheduleRepository.deleteById(id);
    }

}
