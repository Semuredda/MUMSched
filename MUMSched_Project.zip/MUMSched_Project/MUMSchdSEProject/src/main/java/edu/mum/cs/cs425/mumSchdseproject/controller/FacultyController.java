package edu.mum.cs.cs425.mumSchdseproject.controller;

import java.util.List;
import javax.validation.Valid;

import edu.mum.cs.cs425.mumSchdseproject.model.Faculty;
import edu.mum.cs.cs425.mumSchdseproject.service.*;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class FacultyController {

	@Autowired
    CourseService courseService;
	@Autowired
    UserService userProfileService;

    @Autowired
    FaculityService facultyService;

	@Autowired
    private FaculityService faculityService;

    @RequestMapping(value = "/faculties",method = RequestMethod.GET)
    public ModelAndView students(){
        List<Faculty> faculties = facultyService.findAll();
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("faculties", faculties);
        modelAndView.setViewName("faculty/list");
        return modelAndView;
    }

    @RequestMapping(value="/faculties/new", method = RequestMethod.GET)
    public String create(Model model){
        model.addAttribute("faculty", new Faculty());
        return "faculty/create";
    }

    @RequestMapping(value = "/newfaculty", method = RequestMethod.GET)
    public String edit(@Valid @ModelAttribute("faculty") Faculty faculty,
                       BindingResult result, Model model)  {

        if (result.hasErrors()) {
            model.addAttribute("errors", result.getAllErrors());
            return "faculty/create";
        }
        faculty = faculityService.save(faculty);
        return "redirect:/faculties";
    }

    @RequestMapping(value="/faculty/{id}", method = RequestMethod.GET)
    public String view(@PathVariable Long id, Model model){
        model.addAttribute("faculty", faculityService.findById(id));
        return "faculty/creat";
    }

    @RequestMapping(value="/faculty/delete/{id}", method = RequestMethod.GET)
    public String delete(@PathVariable Long id, Model model){
        faculityService.delete(id);
        return "redirect:/faculties";
    }

}
