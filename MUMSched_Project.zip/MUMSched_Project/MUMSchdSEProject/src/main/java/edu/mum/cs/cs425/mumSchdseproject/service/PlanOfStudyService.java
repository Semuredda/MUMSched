package edu.mum.cs.cs425.mumSchdseproject.service;

import java.util.List;

import edu.mum.cs.cs425.mumSchdseproject.model.PlanOfStudy;

public interface PlanOfStudyService {
	PlanOfStudy save(PlanOfStudy planOfStudy);
	List<PlanOfStudy> findPlanOfStudy();
	void deletePlanOfStudy(Long id);
	PlanOfStudy getPlanOfStudy(Long id);
}
