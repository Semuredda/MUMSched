package edu.mum.cs.cs425.mumSchdseproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value = "/admin/sections")
public class SectionController {

}
