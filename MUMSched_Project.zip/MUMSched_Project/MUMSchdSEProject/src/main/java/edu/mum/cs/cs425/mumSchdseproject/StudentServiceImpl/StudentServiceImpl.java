package edu.mum.cs.cs425.mumSchdseproject.StudentServiceImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.mumSchdseproject.model.Student;
import edu.mum.cs.cs425.mumSchdseproject.repository.StudentRepository;
import edu.mum.cs.cs425.mumSchdseproject.service.StudentService;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

	@Autowired(required=true)
	StudentRepository studentrepository;
	
	@Override
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		return (List<Student>) studentrepository.findAll();
	}

	@Override
	public Student save(Student student) {
		// TODO Auto-generated method stub
		return studentrepository.save(student);
	}

	@Override
	public Student findOne(Long id) {
		// TODO Auto-generated method stub
		return studentrepository.findStudentById(id);
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		studentrepository.deleteById(id);
	}
}
