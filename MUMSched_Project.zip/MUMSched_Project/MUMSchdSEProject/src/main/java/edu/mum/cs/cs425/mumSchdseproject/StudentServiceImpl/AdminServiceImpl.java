package edu.mum.cs.cs425.mumSchdseproject.StudentServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.mumSchdseproject.model.Admin;
import edu.mum.cs.cs425.mumSchdseproject.repository.AdminRepository;



@Service
public class AdminServiceImpl {

	@Autowired
	AdminRepository adminRepository;
	
	public Admin save(Admin admin){
		return  adminRepository.save(admin);
		
	}
	
	public List<Admin> getAll(){
		
		return (List<Admin>) adminRepository.findAll();
	}
	
     public Admin getAdminById(Long id){
		
		return adminRepository.getOne(id);
	}
}
