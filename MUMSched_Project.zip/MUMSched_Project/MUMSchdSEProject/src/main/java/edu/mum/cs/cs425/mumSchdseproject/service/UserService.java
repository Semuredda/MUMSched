package edu.mum.cs.cs425.mumSchdseproject.service;

import edu.mum.cs.cs425.mumSchdseproject.model.Admin;
import edu.mum.cs.cs425.mumSchdseproject.model.Faculty;
import edu.mum.cs.cs425.mumSchdseproject.model.Student;
import edu.mum.cs.cs425.mumSchdseproject.model.User;
import edu.mum.cs.cs425.mumSchdseproject.model.dto.UserDto;

import java.util.List;

public interface UserService {
    public List<User> findAllUsers();
    public List<User> findAllFacultyUsers();
    public List<User> findAllAdminUsers();
    public List<User> findAllStudentUsers();
    public UserDto updateUser(UserDto userDto);
    public Admin createAdminUser(UserDto adminUser);
    public Faculty createFacultyDto(UserDto userDto);
    public Student createStudentUser(UserDto userDto);
    public User findUserById(long id);
    public UserDto createUser(UserDto user);
    void delete(Long id);
}
