package edu.mum.cs.cs425.mumSchdseproject.controller;

import edu.mum.cs.cs425.mumSchdseproject.model.Block;
import edu.mum.cs.cs425.mumSchdseproject.service.BlockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Controller
@RequestMapping(value = "/admin/block")
public class BlockController {
    @Autowired
    BlockService service;

    //    @PreAuthorize("hasRole('ROLE_Admin')")
    @GetMapping("/all")
    public String blockList(Model model)  {
        model.addAttribute("blocks",service.getAllBlock());
        return "block/list";
    }

    //    @PreAuthorize("hasRole('ROLE_Admin')")
    @GetMapping("/add")
    public String addBlock(Model model)
    {
        model.addAttribute("block", new Block());
        return "block/create";
    }

    //    @PreAuthorize("hasRole('ROLE_Admin')")
    @GetMapping("/newBlock")
    public String saveCourse(@Valid @ModelAttribute("block") Block block, BindingResult result, Model model)
    {
        if(result.hasErrors())
        {
            if(!model.containsAttribute("block"))
                return "block/create";
        }
        service.save(block);

        return "redirect:/admin/block/all";

    }

    //    @PreAuthorize("hasRole('ROLE_Admin')")
    @GetMapping(value = "/update/{id}")
    public String editCourse(@PathVariable("id") Long id, Model model) {
        model.addAttribute("block", service.getBlockById(id));
        return "block/create";
    }

    //    @PreAuthorize("hasRole('ROLE_Admin')")
    @PostMapping(value = "/update")
    public String saveEditCourse(@Valid @ModelAttribute Block block,BindingResult result,Model model) {
        if(result.hasErrors())
        {
            if(!model.containsAttribute("block"))
                model.addAttribute("block",block);
                return "block/create";
        }
        service.save(block);
        return "redirect:/admin/block/all";
    }

    @RequestMapping(value="/delete/{id}", method = RequestMethod.GET)
    public String delete(@PathVariable Long id, Model model){
        service.deleteBlock(id);
        return "redirect:/admin/block/all";
    }
}
