package edu.mum.cs.cs425.mumSchdseproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.mum.cs.cs425.mumSchdseproject.model.Entry;

@Repository
public interface EntryRepository extends JpaRepository<Entry,Long>{
	Entry findByEntryMonth(String entryMonth);

}
