package edu.mum.cs.cs425.mumSchdseproject.repository;

import edu.mum.cs.cs425.mumSchdseproject.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.mum.cs.cs425.mumSchdseproject.model.Faculty;


@Repository
public interface FacultyRepository extends JpaRepository<Faculty, Long>{
    public Faculty findByUserProfile(User userProfile);
}