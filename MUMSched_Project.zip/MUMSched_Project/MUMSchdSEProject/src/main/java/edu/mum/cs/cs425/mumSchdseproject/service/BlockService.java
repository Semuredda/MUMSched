package edu.mum.cs.cs425.mumSchdseproject.service;

import java.util.List;

import edu.mum.cs.cs425.mumSchdseproject.model.Block;

public interface BlockService {
	Block getBlockById(Long id);
	List<Block> getAllBlock();
	Block getBlock(String blockMonth);
	void deleteBlock(Long id);
	void updateBlock(Block block);
	List<Block> getAllBlocksByEntryId(Long id);
	Block save(Block block);
}
