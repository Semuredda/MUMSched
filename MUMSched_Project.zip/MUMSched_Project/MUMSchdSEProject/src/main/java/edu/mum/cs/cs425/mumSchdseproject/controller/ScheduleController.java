package edu.mum.cs.cs425.mumSchdseproject.controller;

import edu.mum.cs.cs425.mumSchdseproject.model.Block;
import edu.mum.cs.cs425.mumSchdseproject.model.Schedule;
import edu.mum.cs.cs425.mumSchdseproject.model.dto.ScheduleDto;
import edu.mum.cs.cs425.mumSchdseproject.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

@Controller
@RequestMapping("/admin/schedule")
public class ScheduleController {

    @Autowired
    ScheduleService service;

    @Autowired
    BlockService blockService;

    @Autowired
    CourseService courseService;

    @Autowired
    UserService userService;

    //    @PreAuthorize("hasRole('ROLE_Admin')")
    @GetMapping("/all")
    public String blockList(Model model)  {
        model.addAttribute("schedules",service.findAll());
        return "schedule/list";
    }

    //    @PreAuthorize("hasRole('ROLE_Admin')")
    @GetMapping("/add")
    public String addBlock(Model model)
    {
        model.addAttribute("schedule", new ScheduleDto());
        model.addAttribute("courses", courseService.getAllCourses());
        model.addAttribute("blocks", blockService.getAllBlock());
        model.addAttribute("faculties", userService.findAllFacultyUsers());
        return "schedule/create";
    }

    //    @PreAuthorize("hasRole('ROLE_Admin')")
    @GetMapping("/newSchedule")
    public String saveCourse(@Valid @ModelAttribute ScheduleDto schedule, BindingResult result, Model model)
    {
        if(result.hasErrors())
        {
            if(!model.containsAttribute("schedule"))
                return "schedule/create";
        }
        Schedule scheduleEntity = toScheduleEntity(schedule);
        service.save(scheduleEntity);

        return "redirect:/admin/schedule/all";

    }

    private Schedule toScheduleEntity(ScheduleDto scheduleDto) {
        Schedule schedule = new Schedule();
        schedule.setId(schedule.getId());
        schedule.setBlock(scheduleDto.getBlock());
        schedule.setCourse(scheduleDto.getCourse());
        schedule.setFaculty(scheduleDto.getFaculty());
        return schedule;
    }

    //    @PreAuthorize("hasRole('ROLE_Admin')")
    @GetMapping(value = "/update/{id}")
    public String editCourse(@PathVariable("id") Long id, Model model) {
        model.addAttribute("schedule", service.findById(id));
        return "schedule/create";
    }

    //    @PreAuthorize("hasRole('ROLE_Admin')")
    @PostMapping(value = "/update")
    public String saveEditCourse(@Valid @ModelAttribute Schedule schedule,BindingResult result,Model model) {
        if(result.hasErrors())
        {
            if(!model.containsAttribute("schedule"))
                model.addAttribute("schedule",schedule);
            return "schedule/create";
        }
        service.save(schedule);
        return "redirect:/admin/schedule/all";
    }

    @RequestMapping(value="/delete/{id}", method = RequestMethod.GET)
    public String delete(@PathVariable Long id, Model model){
        service.deleteScheduleById(id);
        return "redirect:/admin/schedule/all";
    }
}
