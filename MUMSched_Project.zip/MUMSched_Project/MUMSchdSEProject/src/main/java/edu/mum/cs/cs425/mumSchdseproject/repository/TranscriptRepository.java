package edu.mum.cs.cs425.mumSchdseproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.mum.cs.cs425.mumSchdseproject.model.Transcript;

@Repository
public interface TranscriptRepository extends JpaRepository<Transcript,Long>{
	Transcript findByStudentId(Long stId);
}
