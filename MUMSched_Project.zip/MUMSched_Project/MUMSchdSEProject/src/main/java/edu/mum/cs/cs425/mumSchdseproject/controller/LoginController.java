package edu.mum.cs.cs425.mumSchdseproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.mum.cs.cs425.mumSchdseproject.model.User;

@Controller 
public class LoginController {

	@GetMapping("/login")
	public String getLogiFormn() {
		return "login";		
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String login(@ModelAttribute(name="user") User user, Model model) {
		String username=user.getUsername();
		String password=user.getPassword();
		System.out.println("User Name :"+ user);
		if("admin".equals(username) && "admin".equals(password)) {
			return "shared/homelayout";
		}
		model.addAttribute("invalid",true);
		return "login";		
	}
}
