package edu.mum.cs.cs425.mumSchdseproject.service;

import java.util.List;

import edu.mum.cs.cs425.mumSchdseproject.model.Course;

public interface CourseService {
	Course save(Course course);
	List<Course> getAllCourses();
	Course getCourseByName(String courseName);
	Course getCourseById(Long id);
    void delete(Long id);
}
