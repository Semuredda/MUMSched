package edu.mum.cs.cs425.mumSchdseproject.service;

import java.util.List;

import edu.mum.cs.cs425.mumSchdseproject.model.Faculty;
import edu.mum.cs.cs425.mumSchdseproject.model.Schedule;

public interface FaculityService {
	
	List<Schedule> viewSchedules();
	void viewProfile(Long id);
	List<Faculty> findAll();
	Faculty findById(Long id);
	Faculty save(Faculty faculty);
	void delete(Long id);
	//getFacultyByUserProfile
}
