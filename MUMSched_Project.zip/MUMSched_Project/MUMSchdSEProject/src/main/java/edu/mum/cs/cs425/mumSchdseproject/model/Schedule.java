package edu.mum.cs.cs425.mumSchdseproject.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
public class Schedule {


 	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	  private Long id;
// 	  @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
// 	  @JoinColumn (name="entry_id")
//	  private Entry entry;
	  private Date generatedDate = new Date();
	  private String status="Active";

	  @OneToOne
	  private Block block;

	  @OneToOne
	  private Course course;

	  @OneToOne
	  private User faculty;

    public Schedule (){}

    private String schedule;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getGeneratedDate() {
		return generatedDate;
	}
	public void setGeneratedDate(Date generatedDate) {
		this.generatedDate = generatedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
    public String getSchedule() { return schedule; }
    public void setSchedule(String schedule) { this.schedule = schedule; }

	public Block getBlock() {
		return block;
	}

	public void setBlock(Block block) {
		this.block = block;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	public User getFaculty() {
		return faculty;
	}

	public void setFaculty(User faculty) {
		this.faculty = faculty;
	}
}

