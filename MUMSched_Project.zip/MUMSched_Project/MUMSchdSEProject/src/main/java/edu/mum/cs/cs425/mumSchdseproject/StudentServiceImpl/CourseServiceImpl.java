package edu.mum.cs.cs425.mumSchdseproject.StudentServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.mumSchdseproject.model.Course;
import edu.mum.cs.cs425.mumSchdseproject.repository.CourseRepository;
import edu.mum.cs.cs425.mumSchdseproject.service.CourseService;
@Service
public class CourseServiceImpl implements CourseService{
	
	@Autowired
	CourseRepository courseRepository;

	public Course save(Course course) {
		return courseRepository.save(course);
	}

	public List<Course> getAllCourses() {
		return   courseRepository.findAll();
	}

	public Course getCourseByName(String courseName) {
		return courseRepository.findByCourseName(courseName);
	}
	
	public Course getCourseById(Long id){
		return courseRepository.getOne(id);
	}

	@Override
	public void delete(Long id) {
		courseRepository.deleteById(id);
	}

}
