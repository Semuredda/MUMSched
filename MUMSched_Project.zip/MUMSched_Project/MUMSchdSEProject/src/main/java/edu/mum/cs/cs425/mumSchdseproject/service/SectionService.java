package edu.mum.cs.cs425.mumSchdseproject.service;

import java.util.List;

import edu.mum.cs.cs425.mumSchdseproject.model.Course;
import edu.mum.cs.cs425.mumSchdseproject.model.Section;
import edu.mum.cs.cs425.mumSchdseproject.model.Student;

public interface SectionService {
	void saveSection(Section section);
	List<Section> getAllSection();
	Section getSectionById(Long id);
	void deleteSection(Long id);
	void updateSection(Section section);
	Section createSection(Long block_id);
	Section createSection(Long block_id, Course course);
	List<Student> getStudentBySection(Long id);
	List<Section> getSectionsForFaculty(long facultyId);
}
