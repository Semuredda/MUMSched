package edu.mum.cs.cs425.mumSchdseproject.StudentServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.mumSchdseproject.model.PlanOfStudy;
import edu.mum.cs.cs425.mumSchdseproject.repository.PlanOfStudyRepository;
import edu.mum.cs.cs425.mumSchdseproject.service.PlanOfStudyService;

@Service
public class PlanOfStudyImpl implements PlanOfStudyService{
	@Autowired
	PlanOfStudyRepository planOfStudyRepository;
	
	public PlanOfStudy save(PlanOfStudy planOfStudy)
	{
		return planOfStudyRepository.save(planOfStudy);
	}
	
	public List<PlanOfStudy> findPlanOfStudy()
	{
		return  planOfStudyRepository.findAll();
	}
	public void deletePlanOfStudy(Long id){
		planOfStudyRepository.deleteById(id);
	}
	public PlanOfStudy getPlanOfStudy(Long id){
		return planOfStudyRepository.getOne(id);
	}


}
