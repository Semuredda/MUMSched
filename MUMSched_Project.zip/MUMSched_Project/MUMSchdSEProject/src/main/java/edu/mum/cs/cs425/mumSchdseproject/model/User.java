package edu.mum.cs.cs425.mumSchdseproject.model;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name = "users")
public class User {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@NotEmpty(message="please enter user name is requeired")
	private String username;
	
	@NotEmpty(message="please enter password is requeired")
	private String password;
	
	@NotEmpty(message="please enter last name it is requeired")
	private String lastName;

	@NotEmpty(message="please enter first name it is requeired")
	private String firstName;

	@Email(message="please enter a valid email address")
	@NotEmpty(message="please enter last name it is requeired")
	private String email;

	private String userType;

	private Integer enabled;

	@OneToMany(cascade = CascadeType.PERSIST)
	private List<Authority> authorities = new ArrayList<>();

	public User(@NotEmpty(message = "please enter user name is requeired") String username, @NotEmpty(message = "please enter password is requeired") String password, @NotEmpty(message = "please enter last name it is requeired") String lastName, @NotEmpty(message = "please enter first name it is requeired") String firstName, @Email(message = "please enter a valid email address") @NotEmpty(message = "please enter last name it is requeired") String email, String userType, Integer enabled) {
		this.username = username;
		this.password = password;
		this.lastName = lastName;
		this.firstName = firstName;
		this.email = email;
		this.userType = userType;
		this.enabled = enabled;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public User(){}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public Integer getEnabled() {
		return enabled;
	}

	public void setEnabled(Integer enabled) {
		this.enabled = enabled;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public List<Authority> getAuthorities() {
		return authorities;
	}

	public void setAuthorities(List<Authority> authorities) {
		this.authorities = authorities;
	}
	public void addAuthority(Authority authority){
		this.authorities.add(authority);
	}
	@Override
	public String toString() {
		return "Student [username=" + username + ", password=" + password + "]";
	}
}
