package edu.mum.cs.cs425.mumSchdseproject.StudentServiceImpl;

import java.util.List;
import javax.transaction.Transactional;

import edu.mum.cs.cs425.mumSchdseproject.model.Faculty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import edu.mum.cs.cs425.mumSchdseproject.model.Schedule;
import edu.mum.cs.cs425.mumSchdseproject.repository.FacultyRepository;
import edu.mum.cs.cs425.mumSchdseproject.repository.ScheduleRepository;
import edu.mum.cs.cs425.mumSchdseproject.service.FaculityService;



@Service
@Transactional
public class FacultyServiceImpl implements FaculityService{
	
	@Autowired
    FacultyRepository facultyRepository;
	
	@Autowired
	ScheduleRepository 	scheduleRepository ;

	@Override
	public List<Schedule> viewSchedules() {
		// TODO Auto-generated method stub
		return scheduleRepository.findAll();
	}

	@Override
	public void viewProfile(Long id) {
		// TODO Auto-generated method stub
		facultyRepository.getOne(id);
	}

	@Override
	public List<Faculty> findAll() {
		return facultyRepository.findAll();
	}

	@Override
	public Faculty findById(Long id) {
		return facultyRepository.getOne(id);
	}

	@Override
	public Faculty save(Faculty faculty) {
		return facultyRepository.save(faculty);
	}

	@Override
	public void delete(Long id) {

	}

}
