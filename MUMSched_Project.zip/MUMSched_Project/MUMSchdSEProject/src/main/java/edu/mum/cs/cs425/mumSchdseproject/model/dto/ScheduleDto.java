package edu.mum.cs.cs425.mumSchdseproject.model.dto;

import edu.mum.cs.cs425.mumSchdseproject.model.Block;
import edu.mum.cs.cs425.mumSchdseproject.model.Course;
import edu.mum.cs.cs425.mumSchdseproject.model.User;

public class ScheduleDto {
    private Long id;
    private Block block;
    private Course course;
    private User faculty;

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getFaculty() {
        return faculty;
    }

    public void setFaculty(User faculty) {
        this.faculty = faculty;
    }
}
