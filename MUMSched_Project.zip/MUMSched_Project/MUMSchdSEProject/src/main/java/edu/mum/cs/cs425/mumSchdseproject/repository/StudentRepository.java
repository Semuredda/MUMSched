package edu.mum.cs.cs425.mumSchdseproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import edu.mum.cs.cs425.mumSchdseproject.model.Student;
import edu.mum.cs.cs425.mumSchdseproject.model.User;



@Repository("studentRepository")
public interface StudentRepository  extends  JpaRepository<Student, Long>  {
	
	@Query("select s from Student s where s.id= :id")
	public Student findStudentById(@Param("id") Long studentId);
	
	
	@Query("select s from Student s where s.userprofile.email= :email")
	public Student findStudentByEmail(@Param("email") String studentEmail);
	
	public Student findByUserprofile(User userProfile);
}
