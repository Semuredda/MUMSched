package edu.mum.cs.cs425.mumSchdseproject.service;

public interface TranscriptService {

}
