package edu.mum.cs.cs425.mumSchdseproject.controller;

import edu.mum.cs.cs425.mumSchdseproject.model.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import edu.mum.cs.cs425.mumSchdseproject.service.CourseService;
import javax.validation.Valid;

@Controller
@RequestMapping("/admin/course")
public class CourseController {
    @Autowired
    CourseService courseService;

//    @PreAuthorize("hasRole('ROLE_Admin')")
    @GetMapping("/all")
    public String courseList(Model model)
    {
        model.addAttribute("courses",courseService.getAllCourses());
        model.addAttribute("noPre","  ");
        return "course/list";
    }
//    @PreAuthorize("hasRole('ROLE_Admin')")
    @GetMapping("/add")
    public String addCourse(Model model)
    {
        model.addAttribute("course", new Course());
        model.addAttribute("courses",courseService.getAllCourses());

        return "course/create";
    }

//    @PreAuthorize("hasRole('ROLE_Admin')")
    @PostMapping("/newcourse")
    public String saveCourse(@Valid @ModelAttribute("course") Course course, BindingResult result, Model model)
    {
        if(result.hasErrors())
        {
            if(!model.containsAttribute("course"))
//                model.addAttribute("courseList",courseService.getAllCourses());
//            if(!model.containsAttribute("areaList"))
             //   model.addAttribute("areaList",specializationsService.findAllspecalization());
            return "course/create";
        }

//        course.setIsPreReq(false);
//        if(course.getPrerequisite()!=null){
//            course.getPrerequisite().forEach(c->c.setIsPreReq(true));
//        }
        courseService.save(course);

        return "redirect:/admin/course/all";

    }

//    @PreAuthorize("hasRole('ROLE_Admin')")
    @GetMapping(value = "/update/{id}")
    public String editCourse(@PathVariable("id") Long id, Model model) {
        model.addAttribute("course", courseService.getCourseById(id));
        model.addAttribute("courseList",courseService.getAllCourses());
       // model.addAttribute("areaList",specializationsService.findAllspecalization());
        return "course/create";
    }

//    @PreAuthorize("hasRole('ROLE_Admin')")
    @PostMapping(value = "/update")
    public String saveEditCourse(@Valid @ModelAttribute("editedCourse") Course course,BindingResult result,Model model) {
        if(result.hasErrors())
        {
            if(!model.containsAttribute("courseList"))
                model.addAttribute("courseList",courseService.getAllCourses());
            if(!model.containsAttribute("areaList"))
              //  model.addAttribute("areaList",specializationsService.findAllspecalization());
            return "course/create";
        }
        courseService.save(course);
        return "redirect:/admin/course/all";
    }

    @RequestMapping(value="/delete/{id}", method = RequestMethod.GET)
    public String delete(@PathVariable Long id, Model model){
        courseService.delete(id);
        return "redirect:/admin/course/all";
    }
}
