package edu.mum.cs.cs425.mumSchdseproject.service;

import java.util.List;

import edu.mum.cs.cs425.mumSchdseproject.model.Admin;

public interface AdminService {
	Admin getAdminById(Long id);
	Admin save(Admin admin);
	List<Admin> getAll();
}
