package edu.mum.cs.cs425.mumSchdseproject.StudentServiceImpl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.mumSchdseproject.model.Entry;
import edu.mum.cs.cs425.mumSchdseproject.model.Section;
import edu.mum.cs.cs425.mumSchdseproject.repository.EntryRepository;
import edu.mum.cs.cs425.mumSchdseproject.service.EntryService;

@Service
@Transactional
public class EntryServiceImpl implements EntryService{
	
	@Autowired
	private EntryRepository entryRepository;

	public void saveEntry(Entry entry) {
		entryRepository.save(entry);
	}

	public Entry getEntry(Long id) {
		return entryRepository.getOne(id);
	}

	public List<Entry> getAllEntry() {
		return (List<Entry>) entryRepository.findAll();
	}

	public Entry getEntryByMonth(String entryMonth) {
		return entryRepository.findByEntryMonth(entryMonth);
	}

	@Override
	public void deleteEntry(Long id) {
		// TODO Auto-generated method stub
		entryRepository.deleteById(id);
	}

	@Override
	public void updateEntry(String entryMonth, int numOfFpp, int numOfMpp, int numOfUSstudents, Long id) {
		// TODO Auto-generated method stub
//		entryRepository.update(entryMonth, numOfFpp, numOfMpp, numOfUSstudents, id);
	}

	@Override
	public List<Section> getAllSectionsByEntryId(long id) {
		// TODO Auto-generated method stub
		Entry entry = entryRepository.getOne(id);
		List<Section> sections = new ArrayList<>();
		entry.getBlocks().forEach(b-> sections.addAll(b.getSections()));
		return sections;
		
	}

	@Override
	public Entry findByEntryMonth(String entryMonth) {
		// TODO Auto-generated method stub
		return entryRepository.findByEntryMonth(entryMonth);
	}


}
