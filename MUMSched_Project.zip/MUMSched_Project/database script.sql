-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema test
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema test
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `test` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `test` ;

-- -----------------------------------------------------
-- Table `test`.`admin`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`admin` (
  `id` BIGINT(20) NOT NULL,
  `user_profile_id` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FKdi58fyyc496ou5hfjyqheq2ut` (`user_profile_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`authorities`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`authorities` (
  `id` BIGINT(20) NOT NULL,
  `authority` VARCHAR(255) NULL DEFAULT NULL,
  `username` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`block`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`block` (
  `id` BIGINT(20) NOT NULL,
  `block_end_date` DATE NULL DEFAULT NULL,
  `block_month` VARCHAR(255) NULL DEFAULT NULL,
  `block_start_date` DATE NULL DEFAULT NULL,
  `block_year` VARCHAR(255) NULL DEFAULT NULL,
  `entry_id` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FKeoqeqrtytfjbj3i9be2hv4tgi` (`entry_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`course` (
  `id` BIGINT(20) NOT NULL,
  `course_code` VARCHAR(255) NULL DEFAULT NULL,
  `course_desc` VARCHAR(255) NULL DEFAULT NULL,
  `course_name` VARCHAR(255) NOT NULL,
  `is_pre_req` BIT(1) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`course_pre_req_course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`course_pre_req_course` (
  `course_id` BIGINT(20) NOT NULL,
  `prerequisite_id` BIGINT(20) NOT NULL,
  INDEX `FKpmlavfqtogbedyyrs0cjvc70m` (`prerequisite_id` ASC) VISIBLE,
  INDEX `FKm2mg12m6bacd205785ia9ov03` (`course_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`entry`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`entry` (
  `id` BIGINT(20) NOT NULL,
  `entry_month` VARCHAR(255) NULL DEFAULT NULL,
  `entry_year` VARCHAR(255) NULL DEFAULT NULL,
  `num_of_fpp` INT(11) NOT NULL,
  `num_of_fpp_opt` INT(11) NOT NULL,
  `num_of_mpp` INT(11) NOT NULL,
  `num_of_mpp_opt` INT(11) NOT NULL,
  `num_ofusstudents` INT(11) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`faculty`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`faculty` (
  `id` BIGINT(20) NOT NULL,
  `is_availability` BIT(1) NOT NULL,
  `user_profile_id` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK7deaepyv9bem10x0al8eeo0g8` (`user_profile_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`faculty_course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`faculty_course` (
  `faculty_id` BIGINT(20) NOT NULL,
  `course_id` BIGINT(20) NOT NULL,
  INDEX `FKkwjf69xqhf47gh4pw5babhome` (`course_id` ASC) VISIBLE,
  INDEX `FKkoof1mncavm8xmllv16i1tj5b` (`faculty_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`faculty_plan_of_studies`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`faculty_plan_of_studies` (
  `faculty_id` BIGINT(20) NOT NULL,
  `plan_of_studies_id` BIGINT(20) NOT NULL,
  INDEX `FKhh0m02ebke05qaljfxv2fdkms` (`plan_of_studies_id` ASC) VISIBLE,
  INDEX `FKehyrfprw4ut65qss8b1n3x3qf` (`faculty_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`hibernate_sequence`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`hibernate_sequence` (
  `next_val` BIGINT(20) NULL DEFAULT NULL)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`plan_of_study`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`plan_of_study` (
  `id` BIGINT(20) NOT NULL,
  `plan_of_study` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`schedule`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`schedule` (
  `id` BIGINT(20) NOT NULL,
  `generated_date` DATETIME NULL DEFAULT NULL,
  `schedule` VARCHAR(255) NULL DEFAULT NULL,
  `status` VARCHAR(255) NULL DEFAULT NULL,
  `block_id` BIGINT(20) NULL DEFAULT NULL,
  `course_id` BIGINT(20) NULL DEFAULT NULL,
  `faculty_id` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FKtkj3p7m2ytr1xtp5t9yb22xuw` (`block_id` ASC) VISIBLE,
  INDEX `FK1psrumo7fgkd16p438etda0i6` (`course_id` ASC) VISIBLE,
  INDEX `FKixo1p6qnemig9j1qwph4xnkg2` (`faculty_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`section`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`section` (
  `id` BIGINT(20) NOT NULL,
  `limit_capacity` INT(11) NOT NULL,
  `section_code` VARCHAR(255) NULL DEFAULT NULL,
  `block_id` BIGINT(20) NULL DEFAULT NULL,
  `course_id` BIGINT(20) NULL DEFAULT NULL,
  `faculty_id` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FKaepepghsyfalqjm57kfq3p93r` (`block_id` ASC) VISIBLE,
  INDEX `FKoy8uc0ftpivwopwf5ptwdtar0` (`course_id` ASC) VISIBLE,
  INDEX `FKjr6mxmx1phq58hd2sws3nporl` (`faculty_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`section_student`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`section_student` (
  `student_id` BIGINT(20) NOT NULL,
  `section_id` BIGINT(20) NOT NULL,
  PRIMARY KEY (`student_id`, `section_id`),
  INDEX `FK46itef3hykf38wpb2p9wld5bh` (`section_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`student`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`student` (
  `id` BIGINT(20) NOT NULL,
  `degree` VARCHAR(255) NULL DEFAULT NULL,
  `field` VARCHAR(255) NULL DEFAULT NULL,
  `id_number` VARCHAR(255) NULL DEFAULT NULL,
  `entry_id` BIGINT(20) NULL DEFAULT NULL,
  `userprofile_id` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK417hfkrx9ypb1oj0vanhx8khm` (`entry_id` ASC) VISIBLE,
  INDEX `FKiy7dde4m5auaoa5h7uge9cvlr` (`userprofile_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`student_transcript`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`student_transcript` (
  `student_id` BIGINT(20) NOT NULL,
  `transcript_id` BIGINT(20) NOT NULL,
  PRIMARY KEY (`student_id`, `transcript_id`),
  UNIQUE INDEX `UK_jctpxpqsq9pu172vbogh37hob` (`transcript_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`transcript`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`transcript` (
  `id` BIGINT(20) NOT NULL,
  `grade` VARCHAR(255) NULL DEFAULT NULL,
  `course_id` BIGINT(20) NULL DEFAULT NULL,
  `student_id` BIGINT(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FKf0jkjskpe6wb2t9t7ilj84qok` (`course_id` ASC) VISIBLE,
  INDEX `FKeakgitmv4hulgqdlw053yd4vw` (`student_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`users`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`users` (
  `id` BIGINT(20) NOT NULL,
  `email` VARCHAR(255) NULL DEFAULT NULL,
  `enabled` INT(11) NULL DEFAULT NULL,
  `first_name` VARCHAR(255) NULL DEFAULT NULL,
  `last_name` VARCHAR(255) NULL DEFAULT NULL,
  `password` VARCHAR(255) NULL DEFAULT NULL,
  `user_type` VARCHAR(255) NULL DEFAULT NULL,
  `username` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `test`.`users_authorities`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `test`.`users_authorities` (
  `user_id` BIGINT(20) NOT NULL,
  `authorities_id` BIGINT(20) NOT NULL,
  UNIQUE INDEX `UK_4k9modmi5xv8km1qoyfyrjhjt` (`authorities_id` ASC) VISIBLE,
  INDEX `FKq3lq694rr66e6kpo2h84ad92q` (`user_id` ASC) VISIBLE)
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
